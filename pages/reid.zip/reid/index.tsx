/**
 * vendor
 */
import React, { useState, useRef, useEffect } from 'react'
import { NextPage } from 'next'
import classNames from 'classnames'
import { IntlProvider } from 'react-intl'
import Head from 'next/head'
import { useInViewport } from 'react-in-viewport'

import Layout from '../../components/Layout/LayoutPromo'

import useClientSide from '../../hooks/useClientSide'
import Russian from '../../assets/translations/ru.json'

import '@nextcss/reset'
import 'swiper/css'
import 'swiper/css/navigation'
import 'swiper/css/pagination'
import 'swiper/css/mousewheel'
import globalStyle from './global.module.scss'
import headerStyle from './header.module.scss'
import introStyle from './intro.module.scss'
import wayStyle from './way.module.scss'
import youStyle from './you.module.scss'
import streamingStyle from './streaming.module.scss'
import learnStyle from './learn.module.scss'
import instructionStyle from './instruction.module.scss'
import questionsStyle from './questions.module.scss'

// const fontFace = `
//      @font-face {
//         font-family: 'Russo One';
//         src: url('../../assets/fonts/RussoOne/RussoOne-Regular.ttf');
//         src: local('Russo One'), local('RussoOne-Regular'),
//             url('/assets/fonts/RussoOne/RussoOne-Regular.eot?#iefix') format('embedded-opentype'),
//             url('/assets/fonts/RussoOne/RussoOne-Regular.woff2') format('woff2'),
//             url('/assets/fonts/RussoOne/RussoOne-Regular.woff') format('woff'),
//             url('/assets/fonts/RussoOne/RussoOne-Regular.ttf') format('truetype');
//         font-weight: normal;
//         font-style: normal;
//     }  
//  `

interface FAQ {
  question: string
  answer: string
}
const questions: FAQ[] = [
  {
    question: 'Կարո՞ղ եմ վճարել բանկային քարտով:',
    answer:
      'Այո, մենք ընդունում ենք վճարումներ բանկային քարտերով, ինչպես նաև այլ էլեկտրոնային վճարումների համակարգերով:',
  },
  {
    question: 'Հնարավո՞ր է վերադարձնել կոշիկները, եթե չափսը չի համապատասխանում:',
    answer:
      'Այո, դուք կարող եք վերադարձնել կամ փոխանակել կոշիկները 2 օրվա ընթացքում, եթե դրանք չեն կրել և պահվել են իրենց սկզբնական վիճակում:',
  },
  {
    question: 'Ինչքա՞ն ժամանակ է տևում առաքումը:',
    answer:
      'Առաքումը սովորաբար տևում է 1-2 աշխատանքային օր, կախված ձեր գտնվելու վայրից:',
  },
  {
    question: 'Կարո՞ղ եմ ստանալ զեղչ առաջին գնման համար:',
    answer:
      'Այո, մենք առաջարկում ենք հատուկ զեղչեր առաջին գնորդների համար: Մանրամասների համար խնդրում ենք այցելել մեր instagram-ի էջ:',
  },
];

const landFolder = `https://4businessmen.ru/wp-content/uploads/2024/08`;

const Page: NextPage = () => {
  const isClientSide = useClientSide()
  //animations
  const refCaptionBox = useRef<HTMLDivElement>(null)
  const refTiktok = useRef<HTMLDivElement>(null)
  const refTwich = useRef<HTMLDivElement>(null)
  const refYoutube = useRef<HTMLDivElement>(null)
  const refButtonBox = useRef<HTMLDivElement>(null)
  const refGiftBox = useRef<HTMLDivElement>(null)
  const refWayBox = useRef<HTMLDivElement>(null)
  const refYouBox = useRef<HTMLDivElement>(null)
  const refStreamingBox = useRef<HTMLDivElement>(null)
  const refLearnBox = useRef<HTMLDivElement>(null)
  const refInstructionBox = useRef<HTMLDivElement>(null)

  const { enterCount: enterCountCaptionBox } = useInViewport(refCaptionBox)
  const { enterCount: enterCountTiktok } = useInViewport(refTiktok)
  const { enterCount: enterCountTwich } = useInViewport(refTwich, { threshold: [0.1] });
  const { enterCount: enterCountYoutube } = useInViewport(refYoutube)
  const { enterCount: enterCountButtonBox } = useInViewport(refButtonBox)
  const { enterCount: enterCountGiftBox } = useInViewport(refGiftBox)
  const { enterCount: enterCountWayBox } = useInViewport(refWayBox)
  const { enterCount: enterCountYouBox } = useInViewport(refYouBox)
  const { enterCount: enterCountStreamingBox } = useInViewport(refStreamingBox)
  const { enterCount: enterCountLearnBox } = useInViewport(refLearnBox)
  const { enterCount: enterCountInstructionBox } = useInViewport(refInstructionBox)
  useEffect(() => {
    if (enterCountTwich > 0) {
      console.log('Enter count for Twitch:', enterCountTwich);
    }
  }, [enterCountTwich]);

  return (
    <IntlProvider locale='ru' messages={Russian} defaultLocale='ru'>
      <Layout>
        <Head>
          <title>Reid shoes</title>
          <meta
            name='description'
            content='Գտեք ձեր իդեալական կոշիկները և վայելեք հարմարավետ քայլեր ամեն օր։'
          />

          {/* <style dangerouslySetInnerHTML={{ __html: fontFace }} /> */}
        </Head>
        <div className={classNames(globalStyle['streamer-root'])}>

          {/* header */}
          <header className={classNames(headerStyle.header)}>
            <div className='header__container container'>
              <a href='https://www.instagram.com/reid_shoes_abovyan_/' className='header__logo'>
                <picture>
                  <img
                    src={`${landFolder}/reid__logo.png`}
                    alt='logo'
                    className='lazyload'
                    width={328}
                    height={65}
                  />
                </picture>
              </a>
            </div>
          </header>

          <main>
            {/* intro */}
            <section className={introStyle.intro}>
              <div className='intro__container container'>
                <h2 className='intro__heading'>
                  ԲԱՐՁՐՈՐԱԿ
                  <span className='intro__heading-span-1'>ԿՈՇԻԿՆԵՐ</span>
                  <span className='intro__heading-span-2'>
                    ԱՆՎՃԱՐ &nbsp;&nbsp; ԱՌԱՔՈՒՄ
                  </span>
                  {isClientSide && (
                    <div
                      className={classNames('intro__bg-tiktok', {
                        triggered: enterCountTiktok > 0,
                      })}
                      ref={refTiktok}
                    >
                      <img
                        src={`${landFolder}/koshik_41.png`}
                        alt='shoe'
                        className='lazyload'
                        width={154}
                        height={157}
                      />
                    </div>
                  )}
                  {isClientSide && (
                    <div
                      className={classNames('intro__bg-twich', {
                        triggered: enterCountTwich > 0,
                      })}
                      ref={refTwich}
                    >
                      <img
                        src={`${landFolder}/botas_4.png`}
                        alt='shoes'
                        className='lazyload'
                        width={154}
                        height={157}
                      />
                    </div>
                  )}
                  {isClientSide && (
                    <div
                      className={classNames('intro__bg-youtube', {
                        triggered: enterCountYoutube > 0,
                      })}
                      ref={refYoutube}
                    >
                      <img
                        src={`${landFolder}/botas_1.png`}
                        alt='shoes'
                        className='lazyload'
                        width={154}
                        height={157}
                      />
                    </div>
                  )}
                </h2>

                {isClientSide && (
                  <div
                    className={classNames('intro__caption-box', {
                      triggered: enterCountCaptionBox > 0,
                    })}
                    ref={refCaptionBox}
                  >
                    <span className='intro__caption-text'>
                      ՄԵԾ ԸՆՏՐՈՒԹՅՈՒՆ <br /> ԵՎ ԶԵՂՉԵՐ
                    </span>

                    <span className='intro__caption-title'>
                      ՀԱՐՄԱՐԱՎԵՏ ԵՎ
                      <span className='intro__caption-paragraph-small'>
                        ՈՃԱՅԻՆ ԿՈՇԻԿՆԵՐ
                      </span>
                    </span>

                    <span className='intro__caption-text'>
                      ՄԵԾ ՀԱՎԱՔԱԾՈՒ <br />
                      <span className='intro__caption-paragraph'>
                        ՆՈՐԱՁԵՎ ԿՈՇԻԿՆԵՐԻ ՀԱՎԱՔԱԾՈՒ

                      </span>
                    </span>

                    <div className='intro__bg-monitor'>
                      <img
                        src={`${landFolder}/botas_2.png`}
                        alt='shoes'
                        className='lazyload'
                        width={370}
                        height={370}
                      />
                    </div>
                  </div>
                )}

                <div className='intro__caption-box_mob'>
                  {isClientSide && (
                    <div
                      className={classNames('intro__caption-text_wrapper', {
                        triggered: enterCountGiftBox > 0,
                      })}
                      ref={refGiftBox}
                    >
                      <div className='intro__caption-text_mob'>
                        ԶԵՂՉԵՐ
                        <span>
                          ՆՈՐԱՁԵՎ ԿՈՇԻԿՆԵՐԻ ՀԱՎԱՔԱԾՈՒ
                        </span>
                      </div>
                    </div>
                  )}
                  <div className='intro-caption-text2_mob'>
                    Ոճ և հարմարավետություն յուրաքանչյուր քայլում
                  </div>

                  <div className='intro__button-block'>
                    <a href='https://www.instagram.com/reid_shoes_abovyan_/' className='intro__button'>
                      ԳՆԵԼ ՀԻՄԱ
                    </a>
                    <p className='intro__button-caption'>
                      ԱՆՎՃԱՐ ԱՌԱՔՈՒՄ
                    </p>
                  </div>

                  <div className='intro__span-wrapper'>
                    <div className='intro__weeks-box'>
                      <span className='intro__weeks'>
                        Բարձր որակ
                      </span>
                      <p className='intro__weeks-text'>ցածր գներ</p>
                    </div>

                    <div className='intro__lessons-box'>
                      <span className='intro__lessons'>Որակ եւ յուրահատուկ</span>
                      <p className='intro__lessons-text'>Ոճային դիզայն</p>
                    </div>

                    <div className='intro__lessons-box'>
                      <span className='intro__lessons'>
                        Հարմարավետություն
                      </span>
                      <p className='intro__lessons-text'>
                        Յուրաքանչյուր քայլում
                      </p>
                    </div>
                  </div>
                </div>
                {isClientSide && (
                  <div
                    className={classNames('intro__button-box', {
                      triggered: enterCountButtonBox > 0,
                    })}
                    ref={refButtonBox}
                  >
                    <div className='intro__weeks-box'>
                      <span className='intro__weeks'>
                        որակ եւ յուրահատուկ
                      </span>
                      <p className='intro__weeks-text'>Ոճային դիզայն</p>
                    </div>
                    <div className='intro__button-block'>
                      <a href='https://www.instagram.com/reid_shoes_abovyan_/' className='intro__button'>
                        ԳՆԵԼ ՀԻՄԱ
                      </a>
                      <p className='intro__button-caption'>
                        ԱՆՎՃԱՐ ԱՌԱՔՈՒՄ
                      </p>
                    </div>
                    <div className='intro__lessons-box'>
                      <span className='intro__lessons'>
                        հարմարավետություն
                      </span>
                      <p className='intro__lessons-text'>
                        ամեն քայլում
                      </p>
                    </div>
                  </div>
                )}
                <div className='intro__projector-right-top'>
                  <img
                    src={`${landFolder}/botas_3.png`}
                    alt='shoes'
                    className='lazyload'
                    width={869}
                    height={451}
                  />
                </div>

                <div className='intro__lamp'>
                  <img
                    src={`${landFolder}/koshik5.png`}
                    alt='shoes'
                    className='lazyload'
                    width={591}
                    height={673}
                  />
                </div>

                <div className='intro__projector-right-mob'>
                  <img
                    src={`${landFolder}/koshik_32.png`}
                    alt='shoes'
                    className='lazyload'
                    width={369}
                    height={369}
                  />
                </div>
              </div>
            </section>

            {/* way */}
            <section className={wayStyle.way}>
              <div className='way__container container'>
                <div className='way__title-box'>
                  <h2 className='way__title'>Եթե դուք:</h2>
                  <div className='way__title-line' />
                </div>
                {isClientSide && (
                  <div
                    className={classNames('way__text-box', {
                      triggered: enterCountWayBox > 0,
                    })}
                    ref={refWayBox}
                  >
                    <div className='way__caption'>
                      <div className='way__top-img-1'>
                        <img
                          src={`${landFolder}/koshik10.png`}
                          alt='shoe'
                          className='lazyload'
                          width={222}
                          height={159}
                        />
                      </div>
                      Սիրում եք
                      <br /> որակյալ
                      <br /> կոշիկներ
                    </div>

                    <div className='way__caption'>
                      <div className='way__top-img-2'>
                        <img
                          src={`${landFolder}/koshik_024.png`}
                          alt='fashion'
                          className='lazyload'
                          width={222}
                          height={159}
                        />
                      </div>
                      Հետևում եք
                      <br /> նորաձևությանը
                      <br /> և ոճին
                    </div>

                    <div className='way__caption'>
                      <div className='way__top-img-3'>
                        <img
                          src={`${landFolder}/botas_4.png`}
                          alt='comfort'
                          className='lazyload'
                          width={232}
                          height={189}
                        />
                      </div>
                      Հաշվի առնում եք
                      <br />
                      հարմարավետությունը
                      <br />
                      քայլելիս
                      <div className='way__bot-img-3'>
                        <img
                          src={`${landFolder}/koshik15.png`}
                          alt='arrow'
                          className='lazyload'
                          width={15}
                          height={133}
                        />
                      </div>
                    </div>

                    <div className='way__caption'>
                      <div className='way__top-img-4'>
                        <img
                          src={`${landFolder}/koshik141.png`}
                          alt='care'
                          className='lazyload'
                          width={222}
                          height={159}
                        />
                      </div>
                      Գնահատում եք
                      <br /> առողջությունն ու հարմարավետությունը
                      <br />
                    </div>

                    <div className='way__caption'>
                      <div className='way__top-img-5'>
                        <img
                          src={`${landFolder}/koshik_013.png`}
                          alt='style'
                          className='lazyload'
                          width={221}
                          height={158}
                        />
                      </div>
                      Կամ պարզապես
                      <br />
                      ցանկանում եք ոճային
                      <br />
                      կոշիկներ գնել
                    </div>
                  </div>
                )}

                <div className='way__bottom-box'>
                  <div className='way__bottom-line' />
                  <p className='way__bottom-text'>Դուք ճիշտ տեղում եք!</p>
                  <div className='way__bottom-line' />
                </div>
              </div>
            </section>

            {/* you */}
            <section className={youStyle.you}>
              <div className='you__container container'>
                <div className='you__title-box'>
                  <h2 className='you__title'>Մեզ հետ դուք կգտնեք՝</h2>
                  <div className='you__title-line' />
                </div>

                {isClientSide && (
                  <div
                    className={classNames('you__text-box', {
                      triggered: enterCountYouBox > 0,
                    })}
                    ref={refYouBox}
                  >
                    <div className='you__text'>
                      Անվիճելի ոճ և հարմարավետություն <br />
                      ցանկացած իրավիճակի համար
                      <div className='you__bg-1'>
                        <img
                          src={`${landFolder}/koshik4.png`}
                          alt='shoe selection'
                          className='lazyload'
                          width={222}
                          height={203}
                        />
                      </div>
                    </div>
                    <div className='you__text'>
                      Հետևեք ձեր ոճին <br />
                      և ստեղծեք ձեր անհատական կերպարը
                      <div className='you__bg-2'>
                        <img
                          src={`${landFolder}/koshik_43.png`}
                          alt='shoe care'
                          className='lazyload'
                          width={245}
                          height={240}
                        />
                      </div>
                    </div>
                    <div className='you__text'>
                      Ամեն քայլը՝ վստահության և <br />
                      հարմարավետության շքերթ
                      <div className='you__bg-3'>
                        <img
                          src={`${landFolder}/koshik_44.png`}
                          alt='seasonal shoes'
                          className='lazyload'
                          width={222}
                          height={175}
                        />
                      </div>
                    </div>
                    <div className='you__text'>
                      Ընտրեք այն, ինչ ձեզ մոտեցնում է
                      ինքնավստահության և ներդաշնակության
                      <div className='you__bg-4'>
                        <img
                          src={`${landFolder}/koshik_45.png`}
                          alt='confidence'
                          className='lazyload'
                          width={222}
                          height={201}
                        />
                      </div>
                    </div>
                    <div className='you__text'>
                      Ստեղծեք ոճային հիշողություններ <br />
                      յուրաքանչյուր զույգով
                      <div className='you__bg-5'>
                        <img
                          src={`${landFolder}/koshik_05.png`}
                          alt='shopping satisfaction'
                          className='lazyload'
                          width={222}
                          height={208}
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </section>
            {/* streaming */}
            <section className={streamingStyle.streaming}>
              <div className='streaming__container container'>
                <div className='streaming__line' />

                <h2 className='streaming__title'>
                  <span className='streaming__title-span'>Կոշիկների ընտրությունը</span> —
                  դա կարևոր քայլ ձեր ոճի և հարմարավետության համար
                </h2>

                <div className='streaming__caption'>
                  Մեր հաճախորդները <br className='streaming__br-mob' />
                  <span className='streaming__caption-span'>
                    գտնում են իրենց ոճը
                  </span>{' '}
                  <br className='streaming__br-mob' /> և վայելում ամեն քայլը նոր կոշիկներով
                </div>

                {isClientSide && (
                  <div
                    className={classNames('streaming__content-box', {
                      triggered: enterCountStreamingBox > 0,
                    })}
                    ref={refStreamingBox}
                  >
                    <div className='streaming__content'>
                      <div className='streaming__content-img'>
                        <img
                          src={`${landFolder}/koshik_01.png`}
                          alt='Stylish Shoes'
                          className='lazyload'
                          width={553}
                          height={328}
                        />
                      </div>
                      <h5 className='streaming__content-heading'>
                        Նորաձևություն և Հարմարավետություն
                      </h5>
                      <p className='straeming__content-text'>
                        Մեր խանութը առաջարկում է ամենաարդիական և հարմարավետ կոշիկներ, որոնք
                        համապատասխանում են ձեր ակտիվ կենսակերպին և բարձր պահանջներին։
                      </p>
                    </div>

                    <div className='streaming__content'>
                      <div className='streaming__content-img'>
                        <img
                          src={`${landFolder}/koshik_35.png`}
                          alt='Comfort Shoes'
                          className='lazyload'
                          width={484}
                          height={338}
                        />
                      </div>
                      <h5 className='streaming__content-heading'>
                        Գտեք Ձեր Հարմարավետությունը
                      </h5>
                      <p className='straeming__content-text'>
                        Մեր կոշիկները նախագծված են այնպիսի ձևով, որ դրանք
                        ապահովում են հարմարավետություն ամբողջ օրը՝ առանց զիջելու
                        ոճին և նորաձևությանը։
                      </p>
                    </div>

                    <div className='streaming__content'>
                      <div className='streaming__content-img'>
                        <img
                          src={`${landFolder}/koshik_04.png`}
                          alt='Sport Shoes'
                          className='lazyload'
                          width={450}
                          height={318}
                        />
                      </div>
                      <h5 className='streaming__content-heading'>
                        Ակտիվ Կյանքի Ընտրություն
                      </h5>
                      <p className='straeming__content-text'>
                        Մեր սպորտային կոշիկները իդեալական են մարզումների և ակտիվ
                        կյանքի համար, ապահովելով անթերի աջակցություն և հարմարավետություն։
                      </p>
                    </div>

                    <div className='streaming__content'>
                      <div className='streaming__content-img'>
                        <img
                          src={`${landFolder}/koshik13.png`}
                          alt='Elegant Shoes'
                          className='lazyload streaming__content-img-33'
                          width={584}
                          height={355}
                        />
                      </div>
                      <h5 className='streaming__content-heading'>
                        Էլեգանտություն Յուրաքանչյուր Քայլում
                      </h5>
                      <p className='straeming__content-text'>
                        Եթե փնտրում եք կոշիկներ, որոնք ընդգծում են ձեր էլեգանտությունը և
                        բարձր որակը, մեր հավաքածուն հենց ձեզ համար է։
                      </p>
                    </div>

                    <div className='streaming__content-btn-block'>
                      <p className='streaming__content-paragraph'>
                        Հավանեցի՞ք մեր հավաքածուն:
                      </p>
                      <p className='streaming__content-caption'>
                        Վստահեք մեր փորձին և գտեք ձեր իդեալական զույգը հենց հիմա։
                      </p>
                      <a href='https://www.instagram.com/reid_shoes_abovyan_/' className='streaming__content-btn'>
                        Գնել Հիմա
                      </a>
                    </div>
                  </div>
                )}
              </div>
            </section>

            {/* learn */}
            <section className={learnStyle.learn}>
              <div className='learn__container container'>
                <h2 className='learn__title'>Մեզ հետ դուք կսովորեք:</h2>
                {isClientSide && (
                  <div
                    className={classNames('learn__box', {
                      triggered: enterCountLearnBox > 0,
                    })}
                    ref={refLearnBox}
                  >
                    <div className='learn__block block-1'>
                      <h5 className='learn__block-heading'>
                        Ընտրել իդեալական կոշիկներ ցանկացած առիթի համար
                      </h5>
                      <p className='learn__block-caption'>
                        Կիմանաք, թե ինչպես ճիշտ ընտրել կոշիկներ տարբեր իրավիճակների և եղանակների համար՝ ապահովելով ոճ և հարմարավետություն։
                      </p>
                    </div>
                    <div className='learn__block block-2'>
                      <h5 className='learn__block-heading'>
                        Հոգ տանել ձեր կոշիկների մասին
                      </h5>
                      <p className='learn__block-caption'>
                        Կսովորեք, ինչպես պահպանել կոշիկների որակը երկար տարիներ՝ օգտագործելով ճիշտ խնամքի միջոցներ։
                      </p>
                    </div>
                    <div className='learn__block block-3'>
                      <h5 className='learn__block-heading'>
                        Համատեղել ոճը և հարմարավետությունը
                      </h5>
                      <p className='learn__block-caption'>
                        Կսովորեք, թե ինչպես համատեղել նորաձևությունն ու հարմարավետությունը՝ ձեր ոճին համապատասխան։
                      </p>
                    </div>
                    <div className='learn__block block-4'>
                      <h5 className='learn__block-heading'>
                        Գտնել ձեր անձնական ոճը
                      </h5>
                      <p className='learn__block-caption'>
                        Կգտնեք ձեր սեփական ոճը մեր լայն տեսականու մեջ և կզգաք ձեր ոճային հնարավորությունները։
                      </p>
                    </div>
                    <div className='learn__block block-5'>
                      <h5 className='learn__block-heading'>
                        Հավաքել իդեալական հավաքածու
                      </h5>
                      <p className='learn__block-caption'>
                        Կսովորեք, ինչպես ընտրել և համադրել կոշիկները՝ ստեղծելով ներդաշնակ և ամբողջական կերպար։
                      </p>
                    </div>
                    <div className='learn__block block-6'>
                      <h5 className='learn__block-heading'>
                        Հավասարակշռել բարձր որակը և մատչելիությունը
                      </h5>
                      <p className='learn__block-caption'>
                        Կիմանաք, ինչպես գտնել կոշիկներ, որոնք համատեղում են բարձր որակը և մատչելի գինը՝ առանց զիջումների։
                      </p>
                    </div>
                  </div>
                )}
                <div className='learn__bottom'>
                  <p className='learn__paragraph'>Հետաքրքրե՞ց:</p>
                  <p className='learn__button-caption'>
                    Գտեք ձեր իդեալական զույգը այսօր
                  </p>
                  <a href='https://www.instagram.com/reid_shoes_abovyan_/' className='learn__button'>
                    Գնել հիմա
                  </a>
                </div>
              </div>
            </section>

            {/* instruction */}
            <section className={instructionStyle.instruction}>
              <div className='instruction__container container'>
                <div className='instruction__title'>
                  Ինչպես ընտրել կոշիկներ?
                  <div className='instruction__title-img'>
                    <img
                      src={`${landFolder}/koshik_06.png`}
                      alt='line'
                      className='lazyload'
                      width={630}
                      height={132}
                    />
                  </div>
                  <div className='instruction__title-img-2'>
                    <img
                      src={`${landFolder}/koshik010.png`}
                      alt='line'
                      className='lazyload'
                      width={630}
                      height={132}
                    />
                  </div>
                </div>
                <div
                  className={classNames('instruction__content-box', {
                    triggered: enterCountInstructionBox > 0,
                  })}
                  ref={refInstructionBox}
                >
                  <div className='instruction__block'>
                    <div className='instruction__block-img'>
                      <img
                        alt='background'
                        src={`${landFolder}/koshik_012.png`}
                        className='lazyload'
                        width={221}
                        height={158}
                      />
                    </div>
                    <p className='instruction__block-text'>
                      Ընտրեք ոճային կոշիկներ՝ հիմնվելով <span>ձեր անհատական ճաշակի</span> վրա
                    </p>
                  </div>

                  <div className='instruction__block'>
                    <div className='instruction__block-img'>
                      <img
                        alt='background'
                        src={`${landFolder}/koshik_08.png`}
                        className='lazyload'
                        width={221}
                        height={158}
                      />
                    </div>
                    <p className='instruction__block-text'>
                      Մեր <span>մասնագետները</span> կօգնեն ձեզ ընտրել ամենահարմարավետ և նորաձև <span>կոշիկները</span>
                    </p>
                  </div>

                  <div className='instruction__block'>
                    <div className='instruction__block-img'>
                      <img
                        alt='background'
                        src={`${landFolder}/koshik_09.png`}
                        className='lazyload'
                        width={221}
                        height={158}
                      />
                    </div>
                    <p className='instruction__block-text'>
                      Պարզեք, թե ինչպես ճիշտ <span>խնամել կոշիկները</span>՝ երկարատև օգտագործման համար
                    </p>
                  </div>

                  <div className='instruction__block'>
                    <div className='instruction__block-img'>
                      <img
                        alt='background'
                        src={`${landFolder}/koshik_011.png`}
                        className='lazyload'
                        width={221}
                        height={158}
                      />
                    </div>
                    <p className='instruction__block-text'>
                      Վայելեք ձեր <span>նոր կոշիկները</span>՝ յուրաքանչյուր քայլով զգալով հարմարավետություն և ոճ
                    </p>
                  </div>
                </div>
              </div>
            </section>
            {/* questions */}
            <section className={questionsStyle.questions} id='faq'>
              <div className='container questions__container'>
                <h2 className='questions__title'>Вопросы и ответы</h2>

                <div className='questions__inner'>
                  <FaqAccordion />
                </div>
              </div>
            </section>
          </main>
        </div>
      </Layout>
    </IntlProvider>
  )
}

export default Page

// faq
const FaqAccordion = () => {
  const [clicked, setClicked] = useState('')
  const handleToggle = (index: string) => {
    if (clicked === index) {
      return setClicked('')
    }
    setClicked(index)
  }
  return (
    <ul className={classNames('questions__list', questionsStyle.questions)}>
      {questions.map((question, idx) => (
        <FaqAccordionItem
          key={idx.toString()}
          question={question.question}
          answer={question.answer}
          onToggle={() => handleToggle(idx.toString())}
          active={clicked === idx.toString()}
        />
      ))}
    </ul>
  )
}

interface AccordionItemProps extends FAQ {
  onToggle: () => void
  active: boolean
}

const FaqAccordionItem = ({
  question,
  answer,
  onToggle,
  active,
}: AccordionItemProps) => {
  return (
    <li
      className={classNames('questions__list-item questions-item', { active })}
    >
      <div
        className={classNames('questions-item__header', { active })}
        onClick={onToggle}
      >
        <h3 className={classNames('questions__item-title', { active })}>
          {question}
        </h3>
        <span />
      </div>
      <div className={classNames('questions-item__body', { active })}>
        <p className='questions__answer'>{answer}</p>
      </div>
      <div className={classNames('questions__bg', { active })} />
    </li>
  )
}
